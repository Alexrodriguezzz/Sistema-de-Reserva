const mysql = require('mysql2');

const db = mysql.createConnection({
  host: 'localhost',
  user: 'root', // Cambia esto si es necesario
  password: 'Pipipopo16', // Cambia esto por tu contraseña
  database: 'sistema_reserva' // Asegúrate de que la base de datos exista
});

db.connect(err => {
  if (err) {
    console.error('Error de conexión: ' + err.stack);
    return;
  }
  console.log('Conectado a la base de datos como ID ' + db.threadId);
});

module.exports = db;