const express = require('express');
const router = express.Router();
const duenoController = require('../controllers/duenoController');

// Obtener todos los dueños
router.get('/', duenoController.getAll);

// Crear un nuevo dueño
router.post('/', duenoController.create);

// Obtener un dueño por ID
router.get('/:id', duenoController.getById);

// Actualizar un dueño por ID
router.put('/:id', duenoController.update);

// Eliminar un dueño por ID
router.delete('/:id', duenoController.delete);

module.exports = router;