const express = require('express');
const router = express.Router();
const reservaController = require('../controllers/reservaController');

// Obtener todas las reservas
router.get('/', reservaController.getAll);

// Crear una nueva reserva
router.post('/', reservaController.create);

// Obtener una reserva por ID
router.get('/:id', reservaController.getById);

// Actualizar una reserva por ID
router.put('/:id', reservaController.update);

// Eliminar una reserva por ID
router.delete('/:id', reservaController.delete);

module.exports = router;