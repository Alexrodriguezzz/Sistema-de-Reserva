const express = require('express');
const router = express.Router();
const resenaController = require('../controllers/resenaController');

// Obtener todas las reseñas
router.get('/', resenaController.getAll);

// Crear una nueva reseña
router.post('/', resenaController.create);

// Obtener una reseña por ID
router.get('/:id', resenaController.getById);

// Actualizar una reseña por ID
router.put('/:id', resenaController.update);

// Eliminar una reseña por ID
router.delete('/:id', resenaController.delete);

module.exports = router;