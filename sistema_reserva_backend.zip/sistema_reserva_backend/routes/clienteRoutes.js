const express = require('express');
const router = express.Router();
const clienteController = require('../controllers/clienteController');

// Obtener todos los clientes
router.get('/', clienteController.getAll);

// Crear un nuevo cliente
router.post('/', clienteController.create);

// Obtener un cliente por ID
router.get('/:id', clienteController.getById);

// Actualizar un cliente por ID
router.put('/:id', clienteController.update);

// Eliminar un cliente por ID
router.delete('/:id', clienteController.delete);

module.exports = router;