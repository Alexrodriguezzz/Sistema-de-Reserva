const express = require('express');
const router = express.Router();
const pagoController = require('../controllers/pagoController');

// Obtener todos los pagos
router.get('/', pagoController.getAll);

// Crear un nuevo pago
router.post('/', pagoController.create);

// Obtener un pago por ID
router.get('/:id', pagoController.getById);

// Actualizar un pago por ID
router.put('/:id', pagoController.update);

// Eliminar un pago por ID
router.delete('/:id', pagoController.delete);

module.exports = router;