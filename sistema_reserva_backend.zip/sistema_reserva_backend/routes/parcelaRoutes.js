const express = require('express');
const router = express.Router();
const parcelaController = require('../controllers/parcelaController');

// Obtener todas las parcelas
router.get('/', parcelaController.getAll);

// Crear una nueva parcela
router.post('/', parcelaController.create);

// Obtener una parcela por ID
router.get('/:id', parcelaController.getById);

// Actualizar una parcela por ID
router.put('/:id', parcelaController.update);

// Eliminar una parcela por ID
router.delete('/:id', parcelaController.delete);

module.exports = router;