const db = require('../config/db');

exports.getAll = (req, res) => {
  db.query('SELECT * FROM cliente', (error, results) => {
    if (error) return res.status(500).send(error);
    res.json(results);
  });
};

exports.create = (req, res) => {
  const { nombre, apellido, correo, telefono } = req.body;
  db.query('INSERT INTO cliente (Nombre, Apellido, Correo, Telefono) VALUES (?, ?, ?, ?)', 
    [nombre, apellido, correo, telefono], 
    (error, results) => {
      if (error) return res.status(500).send(error);
      res.status(201).json({ id: results.insertId, nombre, apellido });
    });
};

exports.getById = (req, res) => {
  const { id } = req.params;
  db.query('SELECT * FROM cliente WHERE id = ?', [id], (error, results) => {
    if (error) return res.status(500).send(error);
    if (results.length === 0) return res.status(404).send('Cliente no encontrado');
    res.json(results[0]);
  });
};

exports.update = (req, res) => {
  const { id } = req.params;
  const { nombre, apellido, correo, telefono } = req.body;
  db.query('UPDATE cliente SET Nombre = ?, Apellido = ?, Correo = ?, Telefono = ? WHERE id = ?', 
    [nombre, apellido, correo, telefono, id], 
    (error, results) => {
      if (error) return res.status(500).send(error);
      res.send('Cliente actualizado');
    });
};

exports.delete = (req, res) => {
  const { id } = req.params;
  db.query('DELETE FROM cliente WHERE id = ?', [id], (error, results) => {
    if (error) return res.status(500).send(error);
    res.send('Cliente eliminado');
  });
};