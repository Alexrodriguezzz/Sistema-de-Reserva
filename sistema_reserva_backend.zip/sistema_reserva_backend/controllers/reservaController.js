const db = require('../config/db');

exports.getAll = (req, res) => {
  db.query('SELECT * FROM reserva', (error, results) => {
    if (error) return res.status(500).send(error);
    res.json(results);
  });
};

// Implementa las demás funciones: create, getById, update, delete