const db = require('../config/db');

exports.getAll = (req, res) => {
  db.query('SELECT * FROM dueno', (error, results) => {
    if (error) return res.status(500).send(error);
    res.json(results);
  });
};

exports.create = (req, res) => {
  const { Nombre, Apellido, Correo, Telefono, Parcela } = req.body;
  db.query('INSERT INTO dueno (Nombre, Apellido, Correo, Telefono, Parcela) VALUES (?, ?, ?, ?, ?)', 
    [Nombre, Apellido, Correo, Telefono, Parcela], 
    (error, results) => {
      if (error) return res.status(500).send(error);
      res.status(201).json({ id: results.insertId, Nombre, Apellido });
    });
};

// Asegúrate de que las demás funciones estén definidas si las necesitas