const db = require('./config/db');


// Implementa las demás funciones: create, getById, update, delete
const express = require('express');
const app = express();
const port = 3000;

// Middleware para parsear JSON
app.use(express.json());

// Importar rutas
const clienteRoutes = require('./routes/clienteRoutes');
const duenoRoutes = require('./routes/duenoRoutes');
const pagoRoutes = require('./routes/pagoRoutes');
const parcelaRoutes = require('./routes/parcelaRoutes');
const resenaRoutes = require('./routes/resenaRoutes');
const reservaRoutes = require('./routes/reservaRoutes');

// Usar rutas
app.use('/api/cliente', clienteRoutes);
app.use('/api/duenos', duenoRoutes);
app.use('/api/pago', pagoRoutes);
app.use('/api/parcela', parcelaRoutes);
app.use('/api/resena', resenaRoutes);
app.use('/api/reserva', reservaRoutes);

// Manejo de errores
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).send('Algo salió mal!');
});

// Iniciar servidor
app.listen(port, () => {
  console.log("Servidor corriendo en http://localhost:${port}");
});